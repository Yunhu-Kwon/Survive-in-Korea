# State Farm VGG 최종 개선 패키지

최신 모델은 **운전자 5-fold CV + 전체/크롭 1:1 결합 + 얼굴 보정 0.5 + 클래스별 확률 보정**입니다.
전체 26명 OOF Log Loss **0.25035**, 정확도 **91.80%**입니다.
실제 최종 제출: **Public 0.23784 / Private 0.20226**. Private는 이전 0.21735보다 개선됐고 Public은 이전 0.22783보다 악화했습니다.
[전체 변경 과정과 붙여넣기용 표](RESULTS.md)를 확인하세요.

## 저장소에서 실행

```bash
pip install -r requirements-vgg.txt
python -m src.vgg.run --input /path/to/statefarm --dry-run
python -m src.vgg.run --input /path/to/statefarm
```

이 명령은 `configs/vgg/vgg16-final-cv.yaml`을 읽고 전체 이미지 CV → 크롭 CV → 얼굴 전체 학습 → 최종 보정을 순서대로 실행합니다.
Linux + CUDA 환경이 필요하며, 입력 폴더에는 공식 CSV와 `imgs/train`, `imgs/test`가 있어야 합니다.
기본 출력은 로컬 `outputs/vgg/vgg16-final-cv/`, Kaggle에서는 `/kaggle/working/vgg16-final-cv/`입니다.
결과는 출력 폴더의 `final/submission.csv`입니다. 일부 단계만 다시 실행하려면 `--steps calibrate_final`처럼 지정하세요.
재실행 시 같은 출력 경로의 해당 단계 결과를 덮어쓰므로 새 실험에는 `--output`으로 새 폴더를 지정하세요.

Kaggle에서는 `notebooks/vgg/VGG_FINAL.ipynb`를 업로드하는 방법이 가장 간단합니다.

## 모델과 평가 범위

- 전체/크롭: ImageNet VGG16-BN의 합성곱 특징 + GAP + 10클래스 분류기. 표준 FC 분류층을 수정한 VGG16 계열입니다.
- 얼굴: ImageNet VGG16 특징 + GAP + c0/c9 이진 분류기. VGG19, ResNet, GoogLeNet과의 혼합은 없습니다.
- 최종 모델은 단일 VGG16 한 개가 아니라 VGG16 계열 여러 fold와 뷰의 결합입니다.
- 분할: `splits/vgg_driver_cv_v1.csv`. 팀 `folds_v1.csv`와 다르며 같은 조건의 ResNet 비교 수치로 사용하지 않습니다.
- ImageNet 초기화만 사용하고 테스트 라벨·pseudo-label 학습은 사용하지 않았습니다.
- OOF는 개발 중 선택의 영향을 받은 수치입니다. 완전한 nested CV나 독립 평가가 아닙니다.
- Random/공통 Driver-disjoint 조건의 VGG 비교, 발표용 성능 화면 PDF, 팀 리뷰는 아직 남아 있습니다.

## 검증과 재현 한계

개별 학습 단계는 이전 Kaggle GPU에서 실제 실행했습니다. 기존 예측에 대한 최종 보정도 재검증했습니다.
이번 저장소 구조로 옮긴 뒤 전체 GPU 학습을 다시 실행하지는 않았습니다.
레이어·학습 연산은 유지하고 모델 클래스를 `src/models/vgg16.py`로 분리했습니다.
패키지 문법, 노트북 형식, 모델 정의와 기존 학습 코드의 일치, 분할 배정, 실행 계획을 확인합니다.
의존성은 허용 범위이며 이번 구조의 전체 GPU 환경을 새로 검증·고정한 lock 파일은 아닙니다.

## 파일과 출처

- [개선 과정·실제 Kaggle 점수·검증 표](RESULTS.md)
- [결과 원본과 최종 recipe](results/)
- [실행 설정](../../configs/vgg/vgg16-final-cv.yaml)
- [분할 차이 설명](../../splits/VGG.md)
- [팀 브랜치 적용 방법](../../docs/VGG_UPLOAD.md)

소스는 torchvision VGG16/VGG16-BN ImageNet 모델과 PyTorch 학습 API를 바탕으로 작성했습니다.
주요 변경은 GAP 헤드, 미세조정, EMA·학습 데이터만 이용한 BN 갱신, 운전자 CV, 고정 크롭,
c0/c9 얼굴 보정과 OOF 확률 보정입니다.
학습 이미지·가중치·토큰·대용량 예측은 Git에 포함하지 않았습니다.
최종 CSV 다운로드 링크와 실제 점수는 `results/final_submission.json`에 기록했습니다.
