"""VGG16-family heads used by the final driver-CV pipeline.

ImageNet feature extraction and fine tuning remain in the training stages.
The classifier indices are retained for checkpoint compatibility.
"""
from torch import nn


class VGG16BNGAP(nn.Module):
    def __init__(self,features):
        super().__init__()
        self.features=features
        self.pool=nn.AdaptiveAvgPool2d((1,1))
        self.classifier=nn.Sequential(nn.Identity(),nn.Identity(),nn.Identity(),nn.Identity(),
                                      nn.Identity(),nn.Dropout(.3),nn.Linear(512,10))
    def forward(self,x):
        return self.classifier(self.pool(self.features(x)).flatten(1))


class FaceVGGCV(nn.Module):
    def __init__(self,features):
        super().__init__();self.features=features
        self.pool=nn.AdaptiveAvgPool2d(1)
        self.classifier=nn.Sequential(nn.Dropout(.3),nn.Linear(512,2))
    def forward(self,x):return self.classifier(self.pool(self.features(x)).flatten(1))


class FaceVGG(nn.Module):
    def __init__(self,features):
        super().__init__();self.features=features;self.pool=nn.AdaptiveAvgPool2d((1,1))
        self.classifier=nn.Sequential(nn.Dropout(.3),nn.Linear(512,2))
    def forward(self,x):return self.classifier(self.pool(self.features(x)).flatten(1))
