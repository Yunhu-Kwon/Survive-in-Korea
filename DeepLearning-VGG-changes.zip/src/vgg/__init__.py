"""VGG16 final pipeline; run from the repository root with python -m src.vgg.run."""
