"""Run the recorded VGG16 pipeline from the team repository root.

This runner checks the reproduction manifest and launches the unchanged training
operations as modules. It never authenticates or submits to Kaggle.
"""
import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

import yaml


ROOT = Path(__file__).resolve().parents[2]
STAGES = ('train_full_cv', 'train_crop_cv', 'train_face_full', 'calibrate_final')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def check_manifest(config):
    if config['experiment_id'] != 'vgg16-final-cv' or config['stages'] != list(STAGES):
        raise ValueError('This runner supports only the recorded vgg16-final-cv recipe.')
    expected_sources = {f'src/vgg/{stage}.py' for stage in STAGES}
    if set(config['source_sha256']) != expected_sources:
        raise ValueError('Manifest source list does not match the recorded stages.')
    for name, expected in config['source_sha256'].items():
        if sha(ROOT / name) != expected:
            raise ValueError(f'Source changed: {name}. Record modified experiments under a new ID.')
    if sha(ROOT / 'src/models/vgg16.py') != config['models_sha256']:
        raise ValueError('Recorded model definitions have changed.')
    split = ROOT / config['split']
    if sha(split) != config['split_sha256']:
        raise ValueError('Recorded VGG split has changed.')
    plan = json.loads((ROOT / config['training_plan']).read_text())
    with split.open(newline='', encoding='utf-8') as f:
        rows = list(csv.DictReader(f))
    if len(rows) != 22424 or len({row['image_path'] for row in rows}) != len(rows):
        raise ValueError('VGG split must contain 22,424 unique training images.')
    if {row['driver_id'] for row in rows} != set(plan['driver_folds']):
        raise ValueError('VGG split drivers differ from the recorded plan.')
    if any(int(row['driver_fold']) != plan['driver_folds'][row['driver_id']] for row in rows):
        raise ValueError('Split CSV and recorded driver plan disagree.')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config', type=Path, default=ROOT / 'configs/vgg/vgg16-final-cv.yaml')
    parser.add_argument('--input', type=Path, help='Extracted official competition data root')
    parser.add_argument('--output', type=Path, help='Output root; existing selected stage outputs are overwritten')
    parser.add_argument('--steps', nargs='+', choices=STAGES, default=list(STAGES))
    parser.add_argument('--dry-run', action='store_true', help='Check sources and splits; print commands without GPU work')
    args = parser.parse_args()
    config = yaml.safe_load(args.config.read_text(encoding='utf-8'))
    check_manifest(config)
    input_root = (args.input or (Path('/kaggle/input') if Path('/kaggle/input').is_dir() else ROOT / 'data/raw')).resolve()
    output_root = (args.output or (Path('/kaggle/working/vgg16-final-cv') if Path('/kaggle/working').is_dir() else ROOT / config['output_relative'])).resolve()
    selected = [stage for stage in STAGES if stage in args.steps]
    commands = [[sys.executable, '-m', f'src.vgg.{stage}'] for stage in selected]
    print(json.dumps({'experiment_id': config['experiment_id'], 'manifest_checked': True,
                      'input': str(input_root), 'output': str(output_root),
                      'steps': selected, 'commands': commands,
                      'dry_run': args.dry_run}, ensure_ascii=False, indent=2), flush=True)
    if args.dry_run:
        return
    if not input_root.is_dir():
        parser.error(f'Input folder not found: {input_root}')
    env = os.environ.copy()
    env['STATEFARM_INPUT_ROOT'] = str(input_root)
    env['STATEFARM_OUTPUT_ROOT'] = str(output_root)
    for command in commands:
        subprocess.run(command, cwd=ROOT, env=env, check=True)


if __name__ == '__main__':
    main()
