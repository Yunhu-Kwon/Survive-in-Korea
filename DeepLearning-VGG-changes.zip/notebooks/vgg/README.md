# VGG16 노트북

`VGG_FINAL.ipynb`를 Kaggle에 올리고 State Farm 대회 데이터, GPU, Internet을 연결한 뒤 순서대로 실행합니다.
자체 코드가 모두 들어 있으므로 저장소나 개인 API 토큰을 입력에 추가할 필요는 없습니다.
출력: `/kaggle/working/vgg_final/final/submission.csv`.

단계별 실행: `train_full_cv`, `train_crop_cv`, `train_face_full`, `calibrate_final` 순서의 ipynb.
별도 세션을 쓰면 앞 단계의 `full`, `crop`, `face` 출력 폴더를 같은 `STATEFARM_OUTPUT_ROOT`에 모읍니다.
`history/`에는 최초 VGG16 기준 및 미세조정 기록이 있습니다.

소스 모듈은 `src/vgg/`, 모델 정의는 `src/models/vgg16.py`,
실험과 실제 제출 점수는 `experiments/vgg/RESULTS.md`에 있습니다.
노트북은 자체 실행을 위해 모델 정의를 포함하며 모듈과 구조가 일치하는지 검증했습니다.
