# VGG 설정

- `vgg16-001.yaml`: 기존 공통 학습기에서 VGG16으로 교체해 비교하기 위한 제안 설정. 이 설정의 추가 학습 결과는 아직 없습니다.
- `vgg16-final-cv.yaml`: 실제 최종 VGG 파이프라인 재현 manifest. `python -m src.vgg.run`으로 실행합니다.

최종 학습 단계의 고정된 설정은 `src/vgg/`에 있으며 이 manifest는 코드 해시, 분할, 실행 순서와 기록을 연결합니다.
`parameters` 값을 바꾸는 방식으로 학습 설정을 변경하지 않습니다. 재현과 다른 실험은 별도 ID로 분리합니다.
최종 전체/크롭 모델은 VGG16-BN이고 얼굴 모델은 VGG16입니다. VGG19, ResNet, GoogLeNet은 최종 조합에 없습니다.
