# VGG 최종 분할

`vgg_driver_cv_v1.csv`: 실제 최종 VGG에서 사용한 운전자 5-fold 배정입니다.
22,424장 / 26명이며 각 운전자는 한 fold에만 속합니다. 원본 데이터 해시는
`experiments/vgg/results/cv_training_plan.json`에 기록했습니다.

**기존 `folds_v1.csv`와 fold 배정이 다릅니다.** 기존 파일은 변경하지 않았습니다.
ResNet 공통 분할 실험과 수치를 같은 조건으로 직접 비교하지 마세요.
학습 코드의 고정 배정과 이 CSV의 배정은 패키지 검증에서 일치 여부를 확인합니다.
공통 분할 비교를 추가로 수행한 결과는 아직 없습니다.
