# 팀 저장소의 VGG 브랜치에 적용

팀 main ZIP을 기준으로 VGG 파일을 배치했습니다. 현재 연결에서 `aiast225/DeepLearning`은 404이므로 원격 push는 수행하지 않았습니다.
`VGG` 브랜치는 제공된 snapshot으로 로컬에서 준비했습니다. 실제 팀 브랜치는 아래처럼 **팀 main에서 생성**합니다.

## 변경분 ZIP으로 적용

1. `DeepLearning-VGG-changes.zip`을 다운로드해 임시 폴더에 풉니다.
2. 팀 저장소를 clone하거나 기존 checkout을 엽니다. 작업 중인 변경이 있다면 먼저 정리합니다.
3. 다음 명령으로 브랜치를 만듭니다.

```bash
git clone https://github.com/aiast225/DeepLearning.git
cd DeepLearning
git switch main
git pull --ff-only origin main
git switch -c VGG
```

이미 VGG 브랜치가 있다면 새로 만들거나 덮어쓰지 말고 `git switch VGG` 후 기존 내용을 먼저 확인하세요.

4. 변경분 ZIP의 **내용물**을 저장소 루트에 복사합니다. src, configs, notebooks 등이 기존 폴더와 나란히 위치해야 합니다.
5. README.md, docs/comparison.md, experiments/results.csv는 기존 파일 수정입니다. 팀 main이 ZIP 이후 바뀌었다면 이 세 파일은 VGG 관련 부분만 합쳐 기존 팀 변경을 보존하세요.
6. 확인하고 업로드합니다.

```bash
python -m src.vgg.run --dry-run
git diff --stat
git status --short
git add README.md docs/comparison.md docs/VGG_UPLOAD.md configs/vgg notebooks/vgg src/vgg src/models/vgg16.py splits/VGG.md splits/vgg_driver_cv_v1.csv experiments/vgg experiments/results.csv requirements-vgg.txt
git commit -m "Add VGG16 final pipeline and measured results"
git push -u origin VGG
```

이후 GitHub에서 main ← VGG Pull Request를 생성해 팀 리뷰를 받습니다. main 병합은 이 작업에 포함하지 않았습니다.

## 패치로 적용하는 방법

변경분 복사 대신 `VGG.patch`를 사용할 수 있습니다. 위 명령으로 팀 main에서 VGG 브랜치를 만든 뒤:

```bash
git apply --check /path/to/VGG.patch
git apply /path/to/VGG.patch
```

첫 명령이 실패하면 파일이 바뀐 것이므로 강제로 적용하지 말고 변경 부분을 수동으로 합칩니다.
전체 구조를 보려면 `DeepLearning-VGG.zip`을 사용하세요. 기존 팀 저장소를 전체 ZIP으로 덮어쓰지는 마세요.

## 확인 사항

- `VGG_FINAL.ipynb`는 Kaggle에 직접 업로드해 실행할 수 있습니다.
- VGG16-BN 전체/크롭 + VGG16 얼굴 모델이며 VGG19는 최종에 없습니다.
- 실제 최종 점수는 Private 0.20226 / Public 0.23784입니다. 목표 0.18에는 도달하지 않았습니다.
- 기존 공통 분할과 VGG 최종 CV 분할이 다르므로 동일 조건의 모델 비교는 추가 평가가 필요합니다.
- 구조 변경 뒤 전체 GPU 학습을 재실행하지 않았습니다.
