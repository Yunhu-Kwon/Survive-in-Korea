# 모델 종합 비교

각 모델의 최종 정리를 완료한 뒤 결과를 추가합니다. 초기 공통 조건 비교와 모델별 최적화 결과를 구분합니다.

## 초기 공통 조건 비교

공통 분할·전처리·학습 예산·평가 방법: `splits/folds_v1.csv` (Random = random_fold 0, Driver-disjoint = driver_fold 0), 224×224 ImageNet 정규화, 증강 없음, Adam 1e-4, 5에폭, 검증 log loss (ResNet50 기준: resnet50-001/002)

| 모델 | 실험 ID | Random 검증 loss | Driver-disjoint 검증 loss | Driver-disjoint 정확도 | 학습 시간 |
|---|---|---|---|---|---|
| ResNet50 | resnet50-001 / 002 | 0.0172 | 0.4316 | 0.879 | 약 8분 |
| VGG (세부 버전 미정) | 미정 | — | — | — | — |
| GoogLeNet | 미정 | — | — | — | — |

## 모델별 최적화 결과

| 모델 | 최종 실험 ID | 검증 분할 | 검증 loss | 최종 설정·차이 | Kaggle loss |
|---|---|---|---|---|---|
| ResNet50 | resnet50-033 (설정 022) | driver_fold 0 / 1 | 0.2748 / 0.1267 | 224, 강한 증강, EMA 0.999, T 보정, 26명 전원 4에폭 | 0.19591 / 0.17442 (Private / Public) |
| VGG16 계열 | vgg16-final-cv | 별도 운전자 5-fold OOF | 0.25035 | VGG16-BN 전체/크롭, VGG16 얼굴, 확률 보정 | 0.20226 / 0.23784 (Private / Public) |
| GoogLeNet | 미정 | 미정 | — | 미정 | — |

**VGG 최종 OOF는 ResNet의 `folds_v1.csv`와 다른 운전자 배정입니다.** 모델별 최적화 결과이며 같은 조건의 성능 우열로 해석하지 않습니다. VGG의 공통 Random/Driver-disjoint 비교는 아직 미측정입니다. [VGG 상세](../experiments/vgg/README.md)

## 분석할 질문

- Random과 Driver-disjoint의 차이는 어느 정도이며, 원인은 무엇인가?
- 새로운 운전자에서 가장 좋은 모델과 개선 방법은 무엇인가?
- 헷갈리는 클래스와 대표 실패 사례는 무엇인가?
- Ablation 결과가 최종 방법의 선택을 뒷받침하는가?
- 추가 학습 시간 대비 성능 개선은 어느 정도인가?
- 단일 분할·시드 등 결과 해석의 한계는 무엇인가?

## 확장 과제

주제·담당·완료 기준·결과 위치: 미정

## 발표 및 제출 점검

- [ ] 세 모델 최종 정리와 종합 비교 완료
- [ ] 확장 과제 결과 정리
- [ ] 데이터 분할·학습 곡선·혼동행렬·개선·Ablation 시각화
- [ ] 모델별 Kaggle 성능 캡처 및 제출용 PDF
- [ ] 발표 PPT, 역할 분담, 8분 리허설
- [ ] 다른 팀원이 README에 따라 실행 가능한지 확인
- [ ] 모든 모델 코드와 최종 실행 설정 포함
